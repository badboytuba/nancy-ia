<?php
/**
 * Plugin Name: Nancy IA
 * Description: Um plugin de widget flutuante de chat para WordPress com o nome Nancy IA.
 * Version: 1.0
 * Author: Your Name
 */

function nancy_ia_plugin_menu() {
    add_options_page('Nancy IA', 'Nancy IA', 'manage_options', 'nancy-ia', 'nancy_ia_options_page');
}
add_action('admin_menu', 'nancy_ia_plugin_menu');

function nancy_ia_options_page() {
    ?>
    <div class="wrap">
        <h1>Nancy IA</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('nancy_ia_options');
            do_settings_sections('nancy_ia');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function nancy_ia_admin_init() {
    register_setting('nancy_ia_options', 'nancy_ia_options', 'nancy_ia_options_validate');
    
    add_settings_section('nancy_ia_image_section', 'Imagem do Widget', 'nancy_ia_image_section_text', 'nancy_ia');
    add_settings_field('nancy_ia_image', 'Imagem', 'nancy_ia_image_field', 'nancy_ia', 'nancy_ia_image_section');

    add_settings_section('nancy_ia_position_section', 'Posicionamento do Widget', 'nancy_ia_position_section_text', 'nancy_ia');
    add_settings_field('nancy_ia_position', 'Posição', 'nancy_ia_position_field', 'nancy_ia', 'nancy_ia_position_section');
}
add_action('admin_init', 'nancy_ia_admin_init');

function nancy_ia_image_section_text() {
    echo '<p>Selecione a imagem para o widget de chat.</p>';
}

function nancy_ia_image_field() {
    $options = get_option('nancy_ia_options');
    $image = isset($options['image']) ? $options['image'] : '';
    echo '<input type="hidden" id="nancy_ia_image" name="nancy_ia_options[image]" value="' . esc_attr($image) . '">';
    echo '<input type="button" class="button" id="nancy_ia_upload_image_button" value="Escolher Imagem">';
    echo '<div id="nancy_ia_preview_image" style="margin-top: 10px;">';
    if (!empty($image)) {
        echo '<img src="' . esc_attr($image) . '" style="max-width: 200px;">';
    }
    echo '</div>';
}

function nancy_ia_position_section_text() {
    echo '<p>Escolha o posicionamento do widget de chat na tela.</p>';
}

function nancy_ia_position_field() {
    $options = get_option('nancy_ia_options');
    $position = isset($options['position']) ? $options['position'] : 'bottom-right';
    $positions = array('bottom-left', 'bottom-right', 'top-left', 'top-right');
    
    echo '<select id="nancy_ia_position" name="nancy_ia_options[position]">';
    foreach ($positions as $pos) {
        $selected = $pos === $position ? 'selected' : '';
        echo "<option value='$pos' $selected>$pos</option>";
    }
    echo '</select>';
}

function nancy_ia_options_validate($input) {
    $newinput['image'] = isset($input['image']) ? esc_url_raw($input['image']) : '';
    $newinput['position'] = isset($input['position']) ? sanitize_text_field($input['position']) : 'bottom-right';
    return $newinput;
}

function nancy_ia_chat_widget() {
    $options = get_option('nancy_ia_options');
    $image_url = isset($options['image']) ? $options['image'] : '';
    $position = isset($options['position']) ? $options['position'] : 'bottom-right';

    if (!empty($image_url)) {
        ?>
        <div id="nancy-ia-chat-widget" class="<?php echo esc_attr($position); ?>">
            <img src="<?php echo esc_attr($image_url); ?>" alt="Nancy IA Chat">
            <!-- Insira aqui o código HTML para o widget de chat -->
        </div>
        <?php
    }
}
add_action('wp_footer', 'nancy_ia_chat_widget');

function nancy_ia_admin_scripts() {
    wp_enqueue_media();
    wp_enqueue_script('nancy-ia-admin-script', plugins_url('js/admin-script.js', __FILE__), array('jquery'));
}
add_action('admin_enqueue_scripts', 'nancy_ia_admin_scripts');

function nancy_ia_enqueue_scripts() {
    wp_enqueue_style('nancy-ia-style', plugins_url('css/style.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'nancy_ia_enqueue_scripts');
