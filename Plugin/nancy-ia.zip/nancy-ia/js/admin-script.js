// admin-script.js
jQuery(document).ready(function ($) {
    var custom_uploader;

    $('#nancy_ia_upload_image_button').click(function (e) {
        e.preventDefault();

        if (custom_uploader) {
            custom_uploader.open();
            return;
        }

        custom_uploader = wp.media.frames.file_frame = wp.media({
            title: 'Escolher Imagem',
            button: {
                text: 'Escolher Imagem'
            },
            multiple: false
        });

        custom_uploader.on('select', function () {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $('#nancy_ia_image').val(attachment.url);
            $('#nancy_ia_preview_image').html('<img src="' + attachment.url + '" style="max-width: 200px;">');
        });

        custom_uploader.open();
    });
});
