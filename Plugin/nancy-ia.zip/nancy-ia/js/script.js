// script.js
jQuery(document).ready(function($) {
    // Insira aqui o código JavaScript para o widget de chat
});
